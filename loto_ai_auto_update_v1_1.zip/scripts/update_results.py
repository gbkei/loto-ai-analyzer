"""Fetch public draw-history tables. Fail closed if extraction is uncertain.
Run by GitHub Actions; verify against published source before relying on results.
"""
import json, re, datetime, pathlib, urllib.request
from bs4 import BeautifulSoup
ROOT=pathlib.Path(__file__).resolve().parents[1]
SOURCES={
 'loto6':('https://takarakuji-loto6.jp/LotoNumber/HistoryPartOutPut',6,43),
 'loto7':('https://www.takarakuji-loto7.jp/LotoNumber/HistoryPartOutPut',7,37),
}

def fetch(game,url,n,maximum):
 req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; LottoResultsReader/1.0)'})
 with urllib.request.urlopen(req,timeout=25) as r: html=r.read().decode('utf-8','replace')
 soup=BeautifulSoup(html,'html.parser')
 result={}
 for tr in soup.select('tr'):
  cells=[c.get_text(' ',strip=True) for c in tr.find_all(['td','th'],recursive=False)]
  if len(cells)<n+2:continue
  m=re.search(r'第\s*(\d+)\s*回',cells[0])
  if not m:continue
  date=re.search(r'(20\d\d)[/-](\d\d?)[/-](\d\d?)',cells[1])
  if not date:continue
  nums=[]
  for cell in cells[2:2+n]:
   if not re.fullmatch(r'\d{1,2}',cell):break
   nums.append(int(cell))
  if len(nums)!=n or len(set(nums))!=n or not all(1<=x<=maximum for x in nums):continue
  day='-'.join((date[1],date[2].zfill(2),date[3].zfill(2)))
  try: datetime.date.fromisoformat(day)
  except ValueError:continue
  result[int(m[1])]={'round':int(m[1]),'date':day,'nums':sorted(nums)}
 if not result:raise ValueError(f'{game}: no valid table rows; page structure may have changed')
 return sorted(result.values(),key=lambda r:r['round'],reverse=True)

def main():
 dest=ROOT/'data/latest.json'
 previous={}
 if dest.exists():
  try:previous=json.loads(dest.read_text())
  except Exception:pass
 games={};errors=[]
 for name,(url,n,mx) in SOURCES.items():
  try:
   new=fetch(name,url,n,mx)
   old=previous.get('games',{}).get(name,{}).get('draws',[])
   merged={r['round']:r for r in old if isinstance(r,dict) and 'round' in r}
   merged.update({r['round']:r for r in new})
   games[name]={'source':url,'draws':sorted(merged.values(),key=lambda x:x['round'],reverse=True)}
   print(name,len(new),'latest',new[0]['round'])
  except Exception as e:
   errors.append(str(e));print('ERROR',e)
   if name in previous.get('games',{}):games[name]=previous['games'][name]
 if errors:raise RuntimeError('Update failed; no new JSON published: '+'; '.join(errors))
 dest.write_text(json.dumps({'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'games':games},ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':main()
